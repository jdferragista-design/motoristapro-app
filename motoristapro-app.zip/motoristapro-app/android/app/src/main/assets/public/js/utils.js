// MotoristaPro — utilitários puros (parse, moeda em centavos, escape, datas, ids)


function parseVal(val) {
  if (typeof val === 'number') return isNaN(val) ? 0 : val;
  if (!val) return 0;
  const clean = val.toString().replace(',', '.').trim();
  const n = parseFloat(clean);
  return isNaN(n) ? 0 : n;
}


// ---------- Precisão monetária: TODA aritmética em centavos (inteiros) ----------
// Fronteira de entrada: float -> centavos arredondados (elimina 0.1+0.2=0.30000...4)
function toC(v) {
  const n = typeof v === 'number' ? v : parseVal(v);
  return Math.round((isNaN(n) ? 0 : n) * 100) || 0;
}

// Formata centavos (int) -> "R$ x,xx" (único ponto de formatação)
function brlC(cents) {
  return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(cents / 100);
}

function formatBRL(val) { return brlC(toC(val)); }


// Escapa texto do usuário antes de interpolá-lo em innerHTML (evita injeção de HTML/XSS)
function esc(str) {
  return String(str ?? '').replace(/[&<>"']/g, c => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  }[c]));
}


// ---------- Máscara decimal (2 casas) sem precisar digitar vírgula ----------
// Digita só números: "28550" -> "285,50" (modelo centavos, padrão apps de pagamento)
function fmt2(v) {
  const n = parseVal(v);
  return n ? n.toFixed(2).replace('.', ',') : '';
}

function maskCents(input) {
  const digits = input.value.replace(/\D/g, '');
  input.value = digits ? (parseInt(digits, 10) / 100).toFixed(2).replace('.', ',') : '';
}


function formatDate(dStr) {
  if(!dStr) return '';
  const parts = dStr.split('-');
  if(parts.length !== 3) return dStr;
  return `${parts[2]}/${parts[1]}/${parts[0]}`;
}


function getTodayString() {
  const d = new Date();
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}


// ID numérico único (evita colisão de Date.now() no mesmo ms)
function uid() {
  let id = Date.now();
  const taken = new Set([...state.shifts, ...state.expenses, ...state.maintenance].map(x => x.id));
  while (taken.has(id)) id++;
  return id;
}
